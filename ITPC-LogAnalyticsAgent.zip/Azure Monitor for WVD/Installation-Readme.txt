Please visit:
https://github.com/MarcelMeurer/LogAnalytics-for-Citrix-and-RDS

If you have questions: marcel.meurer@sepago.de